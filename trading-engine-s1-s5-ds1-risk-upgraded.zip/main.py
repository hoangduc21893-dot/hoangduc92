"""Daily DS1 technical scan. Signals are research alerts only; no orders are placed."""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import requests

DS1 = ("PVT", "PVS", "MSB", "TVS", "PET", "HAH", "BSR", "VPI", "VGC", "DHC", "VTP", "VPB", "MWG")
DNSE_URL = "https://services.entrade.com.vn/chart-api/v2/ohlcs/stock"
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
HISTORY_PATH = Path(os.getenv("SIGNAL_HISTORY_PATH", "data/signal_history.jsonl"))
MIN_BARS = 100
LOOKBACK_DAYS = 420
REQUEST_TIMEOUT = 20
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; DS1ResearchAgent/1.0)"}


@dataclass
class Signal:
    ticker: str
    regime: str
    strategy: str
    score: int
    entry: float | None
    sl: float | None
    tp1: float | None
    tp2: float | None
    trigger: str
    rr: str
    decision: str
    close: float | None
    as_of: str
    entry_type: str = "—"
    trigger_level: float | None = None
    entry_zone_low: float | None = None
    entry_zone_high: float | None = None
    chase_distance_atr: float | None = None
    rr_tp1: float | None = None
    rr_tp2: float | None = None
    risk_per_share: float | None = None
    decision_reason: str = ""


# Round-trip estimated costs include fees/taxes and are configurable per deployment.
ESTIMATED_ROUND_TRIP_COST_RATE = float(os.getenv("ESTIMATED_ROUND_TRIP_COST_RATE", "0.003"))
MIN_NET_RR_TP1 = float(os.getenv("MIN_NET_RR_TP1", "1.0"))
MIN_NET_RR_TP2 = float(os.getenv("MIN_NET_RR_TP2", "1.8"))
MAX_CHASE_ATR = float(os.getenv("MAX_CHASE_ATR", "0.65"))


def fetch_ohlcv(symbol: str, session: requests.Session | None = None, now: int | None = None) -> pd.DataFrame:
    """Fetch daily bars. DNSE endpoint is queried per symbol; 429/5xx are retried."""
    client = session or requests.Session()
    end = int(now or time.time())
    params = {"symbol": symbol, "from": end - LOOKBACK_DAYS * 86400, "to": end,
              "resolution": "1D"}
    last_error: Exception | None = None
    for attempt in range(4):
        try:
            response = client.get(DNSE_URL, params=params, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            if response.status_code == 429 or response.status_code >= 500:
                if attempt < 3:
                    delay = min(2 ** attempt, 12)
                    retry_after = response.headers.get("Retry-After")
                    time.sleep(min(float(retry_after), 20) if retry_after and retry_after.isdigit() else delay)
                    continue
            response.raise_for_status()
            payload = response.json()
            if not payload.get("t"):
                raise ValueError(f"DNSE returned no bars for {symbol}")
            df = pd.DataFrame({"Date": pd.to_datetime(payload["t"], unit="s", utc=True).tz_convert(None),
                               "Open": payload["o"], "High": payload["h"], "Low": payload["l"],
                               "Close": payload["c"], "Volume": payload["v"]})
            df = df.sort_values("Date").drop_duplicates("Date").reset_index(drop=True)
            if df["Close"].median() < 1000:  # DNSE may express VND prices in thousands.
                df[["Open", "High", "Low", "Close"]] *= 1000
            return df
        except (requests.RequestException, ValueError, KeyError, TypeError) as exc:
            last_error = exc
            if attempt < 3:
                time.sleep(min(2 ** attempt, 12))
    raise RuntimeError(f"DNSE fetch failed for {symbol}: {last_error}")


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    close, high, low = x.Close, x.High, x.Low
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / 14, min_periods=14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / 14, min_periods=14, adjust=False).mean()
    x["RSI14"] = 100 - 100 / (1 + gain / loss.replace(0, float("nan")))
    x["EMA20"] = close.ewm(span=20, min_periods=20, adjust=False).mean()
    x["SMA50"] = close.rolling(50, min_periods=50).mean()
    x["SMA100"] = close.rolling(100, min_periods=100).mean()
    x["ATR14"] = pd.concat([(high-low), (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    x["Vol20"] = x.Volume.rolling(20, min_periods=20).mean()
    x["HH20"] = high.shift(1).rolling(20, min_periods=20).max()
    x["LL20"] = low.shift(1).rolling(20, min_periods=20).min()
    x["HH55"] = high.shift(1).rolling(55, min_periods=55).max()
    x["LL55"] = low.shift(1).rolling(55, min_periods=55).min()
    x["RANGE20"] = (high.rolling(20).max() - low.rolling(20).min()) / close
    x["RANGE60"] = (high.rolling(60).max() - low.rolling(60).min()) / close
    return x


def classify_regime(market_df: pd.DataFrame | None) -> str:
    # Fail closed if the market proxy is unavailable or lacks enough bars.
    if market_df is None or len(market_df) < 100:
        return "CHOPPY"
    x = add_features(market_df).iloc[-1]
    if pd.isna(x.SMA50) or pd.isna(x.SMA100) or pd.isna(x.ATR14) or x.Close <= 0:
        return "CHOPPY"
    trend = x.Close > x.SMA50 > x.SMA100 and x.EMA20 > x.SMA50
    down = x.Close < x.SMA50 < x.SMA100 and x.EMA20 < x.SMA50
    if trend and x.RSI14 >= 48:
        return "TREND"
    if down and x.RSI14 <= 52:
        return "TREND"
    if 35 <= x.RSI14 <= 65 and abs(x.Close / x.SMA50 - 1) < 0.025:
        return "RANGE"
    return "CHOPPY"


def _f(row: pd.Series, key: str, default: float = float("nan")) -> float:
    value = row.get(key, default)
    return float(value) if pd.notna(value) else default


def _net_rr(entry: float, stop: float, target: float, cost_rate: float) -> float:
    """Net reward/risk after estimated round-trip costs (half charged per leg)."""
    side_rate = cost_rate / 2.0
    net_reward = target - entry - side_rate * (entry + target)
    net_risk = entry - stop + side_rate * (entry + stop)
    return net_reward / net_risk if net_risk > 0 else 0.0


def _trade_plan(entry_type: str, close: float, trigger: float, atr: float,
                bar_low: float, bar_high: float, supports: list[float],
                resistances: list[float], cost_rate: float | None = None) -> dict[str, Any]:
    """Build a long-only structure/ATR plan. Exposed for deterministic sanity tests."""
    costs = ESTIMATED_ROUND_TRIP_COST_RATE if cost_rate is None else cost_rate
    zone_pad = 0.20 * atr
    optimal = trigger
    chase_atr = max(0.0, (close - optimal) / atr) if atr > 0 else float("inf")
    result: dict[str, Any] = {"entry_type": entry_type, "trigger_level": trigger,
        "entry_zone_low": max(0.0, optimal - zone_pad), "entry_zone_high": optimal + zone_pad,
        "chase_distance_atr": chase_atr, "entry": None, "sl": None, "tp1": None, "tp2": None,
        "rr_tp1": None, "rr_tp2": None, "risk_per_share": None, "status": "WAIT",
        "decision_reason": ""}
    if chase_atr > MAX_CHASE_ATR:
        result.update(status="CHASE_BLOCKED", decision_reason=f"CHASE_BLOCKED: giá cách entry tối ưu {chase_atr:.2f} ATR (tối đa {MAX_CHASE_ATR:.2f})")
        return result
    entry = optimal
    # Structure stop uses the nearest meaningful swing support with an ATR safety buffer.
    valid_supports = [s for s in supports if 0 < s < entry]
    structure = max(valid_supports) if valid_supports else bar_low
    stop = min(structure - 0.15 * atr, entry - 0.80 * atr)
    if stop <= 0 or stop >= entry:
        result["decision_reason"] = "Không xác định được stop cấu trúc hợp lệ"
        return result
    risk = entry - stop
    # Targets must be actual overhead structure; do not manufacture R multiples as targets.
    overhead = sorted({round(v, 6) for v in resistances if v > entry})
    usable = [v for v in overhead if _net_rr(entry, stop, v, costs) >= MIN_NET_RR_TP1]
    if not usable:
        result.update(entry=entry, sl=stop, risk_per_share=risk,
                      decision_reason="WAIT: kháng cự cấu trúc gần nhất không đạt R:R ròng tối thiểu")
        return result
    tp1 = usable[0]
    later = [v for v in usable[1:] if _net_rr(entry, stop, v, costs) >= MIN_NET_RR_TP2]
    tp2 = later[0] if later else None
    rr1, rr2 = _net_rr(entry, stop, tp1, costs), _net_rr(entry, stop, tp2, costs) if tp2 else None
    result.update(entry=entry, sl=stop, tp1=tp1, tp2=tp2, rr_tp1=rr1, rr_tp2=rr2,
                  risk_per_share=risk)
    if rr1 < MIN_NET_RR_TP1 or tp2 is None:
        result.update(decision_reason="WAIT: không có hai mục tiêu cấu trúc đáp ứng R:R ròng tối thiểu")
        return result
    result.update(status="READY", decision_reason="Trigger xác nhận; Entry/SL/TP theo vùng cấu trúc và ATR")
    return result


def score_signal(ticker: str, bars: pd.DataFrame, regime: str) -> Signal:
    x = add_features(bars)
    as_of = pd.Timestamp(x.iloc[-1].Date).strftime("%Y-%m-%d") if len(x) else "unknown"
    empty = Signal(ticker, regime, "None", 0, None, None, None, None,
                   "Dữ liệu chưa đủ/không hợp lệ", "—", "WAIT / KHÔNG GIAO DỊCH", None, as_of,
                   decision_reason="Dữ liệu chưa đủ/không hợp lệ")
    if len(x) < MIN_BARS:
        return empty
    r, prev = x.iloc[-1], x.iloc[-2]
    needed = ["Close", "Open", "High", "Low", "EMA20", "SMA50", "SMA100", "ATR14", "RSI14", "Vol20", "HH20", "LL20", "HH55", "LL55", "RANGE20", "RANGE60"]
    if any(pd.isna(r[k]) for k in needed) or r.Close <= 0 or r.ATR14 <= 0:
        return empty
    c, atr, rsi = float(r.Close), float(r.ATR14), float(r.RSI14)
    volume_ratio = float(r.Volume / r.Vol20) if r.Vol20 > 0 else 0.0
    uptrend = c > r.SMA50 > r.SMA100 and r.EMA20 > r.SMA50
    setups: list[tuple[int, int, float, str, str]] = []
    # Support/resistance levels from prior 55 bars; current bar excluded.
    prior = x.iloc[-56:-1]
    supports = [float(prior.Low.rolling(5).min().iloc[i]) for i in range(len(prior)) if i >= 4]
    resistances = [float(prior.High.rolling(5).max().iloc[i]) for i in range(len(prior)) if i >= 4]
    # S1 swing: support touch, then bullish close through prior swing high.
    if regime in ("RANGE", "CHOPPY") and 35 <= rsi <= 55 and float(r.Low) <= float(r.LL20) + .5*atr and c > float(prev.High) and c > float(r.Open):
        setups.append((63 + int(rsi < 45)*5 + int(volume_ratio >= 1)*5, 1, float(prev.High), "S1: hỗ trợ và nến tăng vượt đỉnh phiên trước", "SWING_CONFIRMATION"))
    # S2 requires both an extreme and bullish reversal candle.
    if regime == "RANGE" and rsi <= 32 and c > float(prev.Close) and c > float(r.Open) and float(r.Low) <= float(r.LL20) + .3*atr:
        setups.append((65 + int(rsi <= 25)*10 + int(volume_ratio >= .8)*5, 2, float(r.High), "S2: quá bán và nến đảo chiều tăng tại hỗ trợ", "REVERSAL_CONFIRMATION"))
    # Breakout retest: previous bar broke its own 20-bar pivot on volume; current bar retests/holds it.
    prev_pivot = float(x.HH20.iloc[-2])
    prev_vr = float(prev.Volume / prev.Vol20) if pd.notna(prev.Vol20) and prev.Vol20 > 0 else 0.0
    breakout_retest = (float(prev.Close) > prev_pivot and prev_vr >= 1.5 and
                       float(r.Low) <= prev_pivot + .25*atr and c > prev_pivot and c > float(r.Open))
    if breakout_retest:
        setups.append((70 + int(prev_vr >= 2)*10 + int(uptrend)*5, 3, prev_pivot, "S3: breakout có volume, retest pivot và đóng giữ phía trên", "BREAKOUT_RETEST"))
    near_ema20 = float(r.Low) <= float(r.EMA20) + .35*atr and c >= float(r.EMA20)
    near_ema50 = float(r.Low) <= float(r.SMA50) + .35*atr and c >= float(r.SMA50)
    if regime == "TREND" and uptrend and (near_ema20 or near_ema50) and c > float(r.Open) and c > float(prev.High):
        level = float(r.EMA20 if near_ema20 else r.SMA50)
        setups.append((68 + int(volume_ratio >= .8)*7 + int(rsi < 68)*5, 4, level, "S4: hồi EMA20/EMA50 và nến tăng xác nhận", "PULLBACK_CONFIRMATION"))
    near_high = c >= float(r.HH55) - 1.5*atr
    if float(r.RANGE20) < float(r.RANGE60)*.65 and near_high and breakout_retest:
        setups.append((70 + int(prev_vr >= 1.8)*10 + int(uptrend)*5, 5, prev_pivot, "S5: nền co hẹp, breakout có volume và retest pivot", "VCP_BREAKOUT_RETEST"))
    if not setups:
        return Signal(ticker, regime, "None", 0, None, None, None, None,
                      "Chưa có trigger S1–S5 xác nhận; chờ retest/đảo chiều", "—", "WAIT / KHÔNG GIAO DỊCH", c, as_of,
                      decision_reason="Chưa có trigger xác nhận")
    score, idx, trigger_level, trigger, entry_type = max(setups, key=lambda s: s[0])
    plan = _trade_plan(entry_type, c, trigger_level, atr, float(r.Low), float(r.High), supports, resistances)
    name = {1: "S1 Swing", 2: "S2 Mean Reversion", 3: "S3 Breakout Momentum", 4: "S4 Pullback Trend Following", 5: "S5 VCP"}[idx]
    decision = "BUY WATCH / CHỜ XÁC NHẬN" if score >= 70 and plan["status"] == "READY" else "WAIT / KHÔNG GIAO DỊCH"
    if plan["status"] == "CHASE_BLOCKED":
        decision = "CHASE_BLOCKED"
    reason = plan["decision_reason"]
    rr = f"net {plan['rr_tp1']:.2f}R / {plan['rr_tp2']:.2f}R" if plan.get("rr_tp2") is not None else "—"
    return Signal(ticker, regime, name, min(score, 100), plan["entry"], plan["sl"], plan["tp1"], plan["tp2"],
                  trigger, rr, decision, c, as_of, entry_type, trigger_level, plan["entry_zone_low"],
                  plan["entry_zone_high"], plan["chase_distance_atr"], plan["rr_tp1"], plan["rr_tp2"],
                  plan["risk_per_share"], reason)


def record_signals(signals: list[Signal], path: Path = HISTORY_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).isoformat()
    with path.open("a", encoding="utf-8") as out:
        for signal in signals:
            row = asdict(signal) | {"recorded_at": stamp}
            out.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def gemini_review(signals: list[Signal]) -> str:
    """Ask Gemini to challenge/explain Python outputs; it must not recalculate indicators."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return "Gemini review bỏ qua: thiếu GEMINI_API_KEY; tín hiệu Python vẫn được báo cáo."
    from google import genai
    snapshot = [{"ticker": s.ticker, "regime": s.regime, "strategy": s.strategy,
                 "score": s.score, "entry": s.entry, "entry_type": s.entry_type,
                 "trigger_level": s.trigger_level, "entry_zone_low": s.entry_zone_low,
                 "entry_zone_high": s.entry_zone_high, "chase_distance_atr": s.chase_distance_atr,
                 "sl": s.sl, "tp1": s.tp1, "tp2": s.tp2, "rr_tp1": s.rr_tp1,
                 "rr_tp2": s.rr_tp2, "risk_per_share": s.risk_per_share,
                 "decision_reason": s.decision_reason, "trigger": s.trigger, "rr": s.rr,
                 "decision": s.decision, "close": s.close, "as_of": s.as_of} for s in signals]
    prompt = ("Bạn là tầng phản biện cho bộ lọc định lượng. Chỉ dùng snapshot JSON sau. "
              "Không tính lại RSI/ATR/giá/điểm, không đổi Decision, không bịa dữ liệu. "
              "Nêu ngắn gọn rủi ro setup và nhắc WAIT nếu trigger chưa xác nhận. "
              "Đây là cảnh báo tham khảo, không đặt lệnh.\n" + json.dumps(snapshot, ensure_ascii=False))
    for attempt in range(3):
        try:
            response = genai.Client(api_key=api_key).models.generate_content(model=GEMINI_MODEL, contents=prompt)
            return response.text or "Gemini không trả lời; xem điểm và trigger do Python tính."
        except Exception as exc:
            status = getattr(exc, "code", None) or getattr(exc, "status_code", None)
            if attempt < 2 and (status == 429 or (isinstance(status, int) and status >= 500)):
                time.sleep(4 * (attempt + 1))
                continue
            return f"Gemini review không khả dụng ({type(exc).__name__}); xem kết quả Python."
    return "Gemini review không khả dụng; xem kết quả Python."


def _fmt(value: float | None) -> str:
    return f"{value:,.0f}" if value is not None else "—"


def _fmt_ratio(value: float | None) -> str:
    return f"{value:.2f}R" if value is not None else "—"


def format_report(signals: list[Signal], review: str) -> str:
    lines = ["📊 TRADING ENGINE S1–S5 | DS1", "Python scoring • Gemini phản biện • Cảnh báo tham khảo, không đặt lệnh", ""]
    for s in signals:
        lines.extend([f"{s.ticker} | Regime: {s.regime} | Strategy: {s.strategy} | Score: {s.score}/100",
                      f"Entry: {_fmt(s.entry)} ({s.entry_type}) | Zone: {_fmt(s.entry_zone_low)}–{_fmt(s.entry_zone_high)} | SL: {_fmt(s.sl)} | TP1: {_fmt(s.tp1)} | TP2: {_fmt(s.tp2)}",
                      f"Trigger: {s.trigger} @ {_fmt(s.trigger_level)} | Chase: {s.chase_distance_atr:.2f} ATR" if s.chase_distance_atr is not None else f"Trigger: {s.trigger} @ {_fmt(s.trigger_level)}",
                      f"R:R ròng: TP1 {_fmt_ratio(s.rr_tp1)} / TP2 {_fmt_ratio(s.rr_tp2)} | Rủi ro/cp: {_fmt(s.risk_per_share)}",
                      f"Decision: {s.decision} — {s.decision_reason} | Giá: {_fmt(s.close)} | {s.as_of}", ""])
    lines.extend(["Gemini review:", review])
    return "\n".join(lines)


def main() -> int:
    session = requests.Session()
    datasets: dict[str, pd.DataFrame] = {}
    errors: list[str] = []
    for i, ticker in enumerate(("VNINDEX", *DS1)):
        try:
            datasets[ticker] = fetch_ohlcv(ticker, session=session)
        except Exception as exc:
            errors.append(f"{ticker}: {exc}")
        if i < len(DS1):
            time.sleep(0.4)  # be gentle with the public chart endpoint
    regime = classify_regime(datasets.get("VNINDEX"))
    signals = [score_signal(t, datasets[t], regime) if t in datasets else
               Signal(t, regime, "None", 0, None, None, None, None, "Không lấy được dữ liệu", "—", "WAIT / KHÔNG GIAO DỊCH", None, "unknown") for t in DS1]
    record_signals(signals)
    review = gemini_review(signals)
    report = format_report(signals, review)
    if errors:
        report += "\n\nData errors:\n" + "\n".join(errors[:8])
    print(report)
    token, chat_id = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if token and chat_id:
        # Telegram sendMessage allows up to 4096 chars; this compact report is split defensively.
        chunks = [report[i:i+3900] for i in range(0, len(report), 3900)]
        for chunk in chunks:
            response = session.post(f"https://api.telegram.org/bot{token}/sendMessage",
                                    json={"chat_id": chat_id, "text": chunk}, timeout=20)
            response.raise_for_status()
    else:
        print("Telegram chưa cấu hình; chỉ in báo cáo.")
    return 0 if len(datasets) > 1 else 1


if __name__ == "__main__":
    raise SystemExit(main())
