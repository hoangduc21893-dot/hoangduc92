"""Focused tests for the entry and risk-plan decisions."""
import unittest

import numpy as np
import pandas as pd

from main import (_trade_plan, classify_regime, load_market_data, score_signal,
                  DNSE_INDEX_URL, format_report)


class RiskEngineSanityTests(unittest.TestCase):
    def plan(self, kind="PULLBACK_CONFIRMATION", close=100.3, trigger=100.0,
             supports=None, resistances=None):
        return _trade_plan(kind, close, trigger, 2.0, 98.0, 101.0,
                           supports or [97.0], resistances or [106.0, 110.0], cost_rate=0.003)

    def test_valid_pullback(self):
        plan = self.plan()
        self.assertEqual(plan["status"], "READY")
        self.assertEqual(plan["entry_type"], "PULLBACK_CONFIRMATION")
        self.assertAlmostEqual(plan["entry"], 100.0)
        self.assertGreaterEqual(plan["rr_tp1"], 1.0)

    def test_valid_breakout_retest(self):
        plan = self.plan("BREAKOUT_RETEST", close=100.5)
        self.assertEqual(plan["status"], "READY")
        self.assertEqual(plan["entry_type"], "BREAKOUT_RETEST")
        self.assertAlmostEqual(plan["trigger_level"], 100.0)

    def test_chase_blocked_breakout(self):
        plan = self.plan("BREAKOUT_RETEST", close=102.0)
        self.assertEqual(plan["status"], "CHASE_BLOCKED")
        self.assertIn("CHASE_BLOCKED", plan["decision_reason"])

    def test_insufficient_structure_rr_waits(self):
        plan = self.plan(resistances=[102.0, 103.0])
        self.assertEqual(plan["status"], "WAIT")
        self.assertIsNone(plan["tp1"])
        self.assertIn("R:R", plan["decision_reason"])

    def test_stop_uses_structure_with_atr_buffer(self):
        plan = self.plan()
        self.assertAlmostEqual(plan["sl"], 96.7)
        self.assertAlmostEqual(plan["risk_per_share"], 3.3)


def market_bars(count=140):
    dates = pd.date_range("2025-01-01", periods=count, freq="B")
    close = 1000 + np.arange(count) * 3 + 20 * np.sin(np.arange(count) / 4)
    return pd.DataFrame({"Date": dates, "Open": close - 1, "High": close + 5,
                         "Low": close - 5, "Close": close,
                         "Volume": np.full(count, 1_000_000)})


class MarketRegimeSafetyTests(unittest.TestCase):
    def test_valid_market_data_classifies_normally(self):
        regime = classify_regime(market_bars())
        self.assertIn(regime, {"TREND", "RANGE", "CHOPPY"})
        self.assertNotEqual(regime, "REGIME_UNKNOWN")

    def test_missing_or_invalid_market_data_is_unknown(self):
        self.assertEqual(classify_regime(None), "REGIME_UNKNOWN")
        self.assertEqual(classify_regime(market_bars(40)), "REGIME_UNKNOWN")

    def test_unknown_regime_forces_wait_before_any_setup(self):
        signal = score_signal("TEST", market_bars(), "REGIME_UNKNOWN")
        self.assertEqual(signal.regime, "REGIME_UNKNOWN")
        self.assertEqual(signal.decision, "WAIT / KHÔNG GIAO DỊCH")
        self.assertEqual(signal.score, 0)
        self.assertIsNone(signal.entry)
        self.assertIn("REGIME_UNKNOWN", signal.decision_reason)

    def test_valid_vn30_is_used_only_after_vnindex_failure(self):
        vn30 = market_bars()
        def fetch(symbol, endpoint=None):
            self.assertEqual(endpoint, DNSE_INDEX_URL)
            if symbol == "VNINDEX":
                raise RuntimeError("400 Bad Request")
            return vn30
        bars, source, errors = load_market_data(fetch)
        self.assertIs(bars, vn30)
        self.assertEqual(source, "VN30")
        self.assertTrue(errors)

    def test_invalid_vn30_is_not_accepted_as_fallback(self):
        def fetch(symbol, endpoint=None):
            if symbol == "VNINDEX":
                raise RuntimeError("400 Bad Request")
            return market_bars(30)
        bars, source, errors = load_market_data(fetch)
        self.assertIsNone(bars)
        self.assertIsNone(source)
        self.assertEqual(len(errors), 2)


class SetupDiagnosticTests(unittest.TestCase):
    def test_each_signal_contains_explanations_for_all_five_setups(self):
        signal = score_signal("TEST", market_bars(), "CHOPPY")
        self.assertEqual([d.code for d in signal.setup_diagnostics],
                         ["S1", "S2", "S3", "S4", "S5"])
        for diagnostic in signal.setup_diagnostics:
            self.assertIn(diagnostic.status, {"PASS", "FAIL"})
            self.assertTrue(diagnostic.checks)
            if diagnostic.status == "FAIL":
                self.assertTrue(diagnostic.failed_checks)

    def test_unknown_regime_explains_why_each_setup_was_blocked(self):
        signal = score_signal("TEST", market_bars(), "REGIME_UNKNOWN")
        report = format_report([signal], "review skipped")
        self.assertIn("REGIME_UNKNOWN", report)
        self.assertIn("S1 UNKNOWN", report)
        self.assertIn("S5 UNKNOWN", report)


if __name__ == "__main__":
    unittest.main()
