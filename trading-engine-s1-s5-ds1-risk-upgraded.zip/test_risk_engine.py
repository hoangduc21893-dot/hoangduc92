"""Focused tests for the entry and risk-plan decisions."""
import unittest

from main import _trade_plan


class RiskEngineSanityTests(unittest.TestCase):
    def plan(self, kind="PULLBACK_CONFIRMATION", close=100.3, trigger=100.0,
             supports=None, resistances=None):
        return _trade_plan(kind, close, trigger, 2.0, 98.0, 101.0,
                           supports or [97.0], resistances or [106.0, 110.0], cost_rate=0.003)

    def test_valid_pullback(self):
        plan = self.plan()
        self.assertEqual(plan["status"], "READY")
        self.assertEqual(plan["entry_type"], "PULLBACK_CONFIRMATION")
        self.assertAlmostEqual(plan["entry"], 100.0)
        self.assertGreaterEqual(plan["rr_tp1"], 1.0)

    def test_valid_breakout_retest(self):
        plan = self.plan("BREAKOUT_RETEST", close=100.5)
        self.assertEqual(plan["status"], "READY")
        self.assertEqual(plan["entry_type"], "BREAKOUT_RETEST")
        self.assertAlmostEqual(plan["trigger_level"], 100.0)

    def test_chase_blocked_breakout(self):
        plan = self.plan("BREAKOUT_RETEST", close=102.0)
        self.assertEqual(plan["status"], "CHASE_BLOCKED")
        self.assertIn("CHASE_BLOCKED", plan["decision_reason"])

    def test_insufficient_structure_rr_waits(self):
        plan = self.plan(resistances=[102.0, 103.0])
        self.assertEqual(plan["status"], "WAIT")
        self.assertIsNone(plan["tp1"])
        self.assertIn("R:R", plan["decision_reason"])

    def test_stop_uses_structure_with_atr_buffer(self):
        plan = self.plan()
        self.assertAlmostEqual(plan["sl"], 96.7)
        self.assertAlmostEqual(plan["risk_per_share"], 3.3)


if __name__ == "__main__":
    unittest.main()
