"""Mock tests for reviewer behavior and Python signal immutability."""
import json
import os
import sys
import types
import unittest
from unittest.mock import MagicMock, patch

from main import (GEMINI_MODEL, Signal, _gemini_error_details, gemini_review,
                  score_signal)


def review_payload(**overrides):
    payload = {
        "setup_summary": "WAIT setup with unconfirmed trigger",
        "strengths": ["Volume context is available"],
        "weaknesses": ["Trigger confirmation is missing"],
        "primary_risk_blocker": "Trigger not confirmed",
        "fomo_chase_check": "No chase conclusion beyond supplied diagnostics",
        "conditions_before_trigger": ["Wait for trigger and close confirmation"],
        "verdict": "CAUTION",
    }
    payload.update(overrides)
    return json.dumps({"reviews": [{"ticker": "TEST", **payload}]})


def sample_signal(decision="WAIT"):
    return Signal("TEST", "RANGE", "S1", 40, 100.0, 95.0, 110.0, 115.0,
                  "wait for support reaction", "1.8R", decision, 98.0,
                  "2026-10-04", decision_reason="trigger missing")


def fake_genai(response=None, error=None):
    genai = types.SimpleNamespace()
    client = MagicMock()
    if error is not None:
        client.models.generate_content.side_effect = error
    else:
        client.models.generate_content.return_value = response
    genai.Client = MagicMock(return_value=client)
    return genai, client


class GeminiReviewerTests(unittest.TestCase):
    def run_with_genai(self, genai, signal=None):
        google = types.ModuleType("google")
        google.genai = genai
        with patch.dict(sys.modules, {"google": google}), patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}):
            return gemini_review([signal or sample_signal()])

    def test_success_is_structured_and_cannot_upgrade_python_wait(self):
        signal = sample_signal("WAIT")
        before = (signal.decision, signal.entry, signal.sl, signal.tp1, signal.tp2,
                  signal.rr, signal.decision_reason)
        response = types.SimpleNamespace(text=review_payload(decision="BUY", entry=999999))
        genai, client = fake_genai(response=response)

        result = self.run_with_genai(genai, signal)

        self.assertIn("Python Decision: WAIT", result)
        self.assertIn("Reviewer verdict: CAUTION", result)
        self.assertIn("Decision remains WAIT", result)
        self.assertNotIn("BUY", result)
        self.assertEqual(before, (signal.decision, signal.entry, signal.sl, signal.tp1,
                                  signal.tp2, signal.rr, signal.decision_reason))
        client.models.generate_content.assert_called_once()
        self.assertEqual(client.models.generate_content.call_args.kwargs["model"], GEMINI_MODEL)

    def test_missing_key_is_nonfatal_and_does_not_call_sdk(self):
        with patch.dict(os.environ, {}, clear=True):
            result = gemini_review([sample_signal()])
        self.assertIn("MISSING_API_KEY", result)

    def test_api_error_logs_type_status_message_and_redacts_key(self):
        class ApiFailure(RuntimeError):
            code = 429

        genai, _ = fake_genai(error=ApiFailure("quota exhausted for test-secret"))
        with self.assertLogs("trading_engine.gemini", level="ERROR") as captured:
            result = self.run_with_genai(genai)
        log = " ".join(captured.output)
        self.assertIn("exception_type=ApiFailure", log)
        self.assertIn("status=429", log)
        self.assertIn("quota exhausted", log)
        self.assertNotIn("test-secret", log)
        self.assertIn("QUOTA_OR_RATE_LIMIT", result)
        self.assertIn("Python signal/report remains authoritative", result)

    def test_key_model_and_request_errors_are_classified(self):
        cases = [
            (400, "API_KEY_INVALID: key is not valid", "API_KEY_OR_PERMISSION"),
            (404, "Requested model was not found", "MODEL_NOT_FOUND"),
            (400, "Invalid request field", "INVALID_REQUEST"),
            (None, "RESOURCE_EXHAUSTED: quota exceeded", "QUOTA_OR_RATE_LIMIT"),
        ]
        for status, message, expected in cases:
            with self.subTest(expected=expected):
                error = RuntimeError(message)
                if status is not None:
                    error.code = status
                category, _, _ = _gemini_error_details(error, "test-secret")
                self.assertEqual(category, expected)

    def test_malformed_response_falls_back_without_crashing(self):
        genai, _ = fake_genai(response=types.SimpleNamespace(text="not JSON"))
        with self.assertLogs("trading_engine.gemini", level="ERROR") as captured:
            result = self.run_with_genai(genai)
        self.assertIn("category=MALFORMED_RESPONSE", " ".join(captured.output))
        self.assertIn("review unavailable: MALFORMED_RESPONSE", result)

    def test_python_decision_and_risk_outputs_are_unchanged_by_reviewer(self):
        import numpy as np
        import pandas as pd

        dates = pd.date_range("2025-01-01", periods=140, freq="B")
        close = 1000 + np.arange(140) * 3 + 20 * np.sin(np.arange(140) / 4)
        bars = pd.DataFrame({"Date": dates, "Open": close - 1, "High": close + 5,
                             "Low": close - 5, "Close": close, "Volume": 1_000_000})
        signal = score_signal("TEST", bars, "CHOPPY")
        before = (signal.regime, signal.strategy, signal.score, signal.decision,
                  signal.entry, signal.sl, signal.tp1, signal.tp2, signal.rr,
                  signal.rr_tp1, signal.rr_tp2, signal.risk_per_share,
                  signal.chase_distance_atr, signal.decision_reason)
        genai, _ = fake_genai(response=types.SimpleNamespace(text=review_payload(decision="BUY")))

        self.run_with_genai(genai, signal)

        after = (signal.regime, signal.strategy, signal.score, signal.decision,
                 signal.entry, signal.sl, signal.tp1, signal.tp2, signal.rr,
                 signal.rr_tp1, signal.rr_tp2, signal.risk_per_share,
                 signal.chase_distance_atr, signal.decision_reason)
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
