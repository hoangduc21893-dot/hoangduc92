"""Telegram eligibility tests: only Python-confirmed READY S1-S5 setups alert."""
import unittest

from main import (SetupDiagnostic, Signal, eligible_setup_alerts,
                  format_setup_alerts, is_setup_alert_eligible)


def ready_signal(**overrides):
    values = {
        "ticker": "TEST",
        "regime": "TREND",
        "strategy": "S3 Breakout Momentum",
        "score": 85,
        "entry": 100.0,
        "sl": 95.0,
        "tp1": 108.0,
        "tp2": 110.0,
        "trigger": "breakout retest confirmed",
        "rr": "net 1.4R / 1.8R",
        "decision": "BUY WATCH / CHỜ XÁC NHẬN",
        "close": 101.0,
        "as_of": "2026-10-05",
        "trigger_level": 100.0,
        "chase_distance_atr": 0.2,
        "rr_tp1": 1.4,
        "rr_tp2": 1.8,
        "risk_status": "READY",
        "watch_status": "TRIGGER_READY",
        "setup_diagnostics": [SetupDiagnostic(code="S3", status="PASS")],
    }
    values.update(overrides)
    return Signal(**values)


class SetupAlertEligibilityTests(unittest.TestCase):
    def test_ready_trigger_with_risk_approval_is_alerted(self):
        signal = ready_signal()
        self.assertTrue(is_setup_alert_eligible(signal))
        self.assertEqual(eligible_setup_alerts([signal]), [signal])

    def test_wait_fail_far_close_watch_and_chase_are_filtered(self):
        cases = [
            ready_signal(decision="WAIT / KHÔNG GIAO DỊCH"),
            ready_signal(setup_diagnostics=[SetupDiagnostic(code="S3", status="FAIL")]),
            ready_signal(watch_status="FAR"),
            ready_signal(watch_status="CLOSE"),
            ready_signal(watch_status="WATCH"),
            ready_signal(risk_status="CHASE_BLOCKED", decision="CHASE_BLOCKED"),
            ready_signal(chase_distance_atr=0.66),
            ready_signal(risk_status="WAIT"),
        ]
        self.assertEqual(eligible_setup_alerts(cases), [])

    def test_requires_matching_strategy_diagnostic_and_complete_risk_plan(self):
        cases = [
            ready_signal(strategy="None"),
            ready_signal(setup_diagnostics=[SetupDiagnostic(code="S2", status="PASS")]),
            ready_signal(tp2=None),
            ready_signal(rr_tp1=0.99),
            ready_signal(rr_tp2=1.79),
            ready_signal(regime="REGIME_UNKNOWN"),
            ready_signal(score=69),
        ]
        self.assertEqual(eligible_setup_alerts(cases), [])

    def test_alert_output_contains_only_qualified_tickers(self):
        ready, wait = ready_signal(ticker="READY"), ready_signal(
            ticker="WAITING", decision="WAIT / KHÔNG GIAO DỊCH")
        message = format_setup_alerts([ready, wait], "review for READY")
        self.assertIn("READY", message)
        self.assertNotIn("WAITING", message)
        self.assertNotIn("WATCHLIST", message)
        self.assertIn("Risk Engine: READY", message)
        self.assertIn("Anti-Chase: PASS", message)

    def test_empty_eligibility_produces_no_telegram_message(self):
        self.assertIsNone(format_setup_alerts([], "no review"))
        self.assertIsNone(format_setup_alerts(
            [ready_signal(decision="WAIT / KHÔNG GIAO DỊCH")], "no review"))


if __name__ == "__main__":
    unittest.main()
