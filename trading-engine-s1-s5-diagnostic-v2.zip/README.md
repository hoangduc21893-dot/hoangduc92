# Trading Engine S1–S5 + DS1

Python fetches daily OHLCV from DNSE per ticker, calculates indicators and strategy scores, and sends a concise report to Telegram. Gemini receives only the already-calculated snapshot to challenge/explain it; it cannot change scores or decisions. The program never places orders.

## Setup

Install Python 3.11+ dependencies with `python -m pip install -r requirements.txt`. Configure these environment variables in GitHub Actions Secrets:

- `GEMINI_API_KEY`
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

`GEMINI_MODEL` can override the default `gemini-2.5-flash`. If Gemini is unavailable or its key is missing, Python output still runs and reports that the review was skipped.

The scheduled workflow runs weekdays at 15:30 Vietnam time and can also be started manually. It loads VNINDEX from DNSE's index OHLC endpoint (`/ohlcs/index`) and scans DS1: PVT, PVS, MSB, TVS, PET, HAH, BSR, VPI, VGC, DHC, VTP, VPB, MWG. If VNINDEX is unavailable or does not contain enough valid bars, it tries VN30 using the same index endpoint. A fallback is accepted only when it can produce a known regime. If both market series fail validation, the regime is `REGIME_UNKNOWN` and every signal is forced to WAIT with no entry/stop/targets.

Signal history is newline-delimited JSON at `data/signal_history.jsonl`; GitHub Actions restores/saves it through the Actions cache and uploads a 90-day artifact after each run. Cache/artifact retention is managed by GitHub and is not a durable database, so download periodic artifacts if long-term archival is needed.

All scores and thresholds are rule-based starting points, not validated trading performance. Strategy-aware entries require a confirmed trigger: S3/S5 use a volume-backed breakout followed by a bullish retest/hold; S4 uses a pullback to EMA20/EMA50 with bullish confirmation; S1/S2 require swing or reversal confirmation. Each ticker report includes Diagnostic v2 for S1–S5: PASS/FAIL/UNKNOWN per condition, an ordered primary and secondary blocker list, and distance-to-trigger in RSI points, volume ratio, ATR and/or percent. Missing inputs report UNKNOWN and N/A.

The informational Proximity Score is isolated from every signal/risk decision. A PASS condition contributes 1.0; a quantified FAIL contributes `exp(-distance / scale)` using fixed unit scales (0.65 ATR, 3 RSI points, 0.75 percentage points, 0.5 volume ratio, 0.25 range units). A FAIL with no measured distance contributes zero. The per-strategy score is the geometric mean of condition contributions × 100, rounded to an integer, so one far blocker cannot be hidden by several PASS checks. If any condition is UNKNOWN, that strategy score is UNKNOWN (stored as `null`); it is not estimated. All PASS conditions produce 100 / `TRIGGER_READY`. The DS1 Watchlist Ranking sorts each ticker by its highest known S1–S5 proximity score and shows the best strategy, blocker, distance, status, and unchanged Decision. It is monitoring output only and never creates or changes BUY/WAIT. A signal is marked `CHASE_BLOCKED` when price is more than the configured ATR distance above its trigger.

Stops use nearby swing support with an ATR buffer and minimum ATR distance. TP1/TP2 come from overhead price structure. The engine calculates estimated net R:R after round-trip costs and returns WAIT when structure targets cannot meet the configured minimums. Score is a setup score, not a probability.

Configurable environment variables: `MAX_CHASE_ATR` (default `0.65`), `ESTIMATED_ROUND_TRIP_COST_RATE` (default `0.003`, or 0.30% round trip), `MIN_NET_RR_TP1` (default `1.0`), and `MIN_NET_RR_TP2` (default `1.8`). Tune the cost estimate to the account/broker before using alerts. Run the focused checks with `python -m unittest test_risk_engine.py` from this directory. This is a research aid, not financial advice.
