"""Daily DS1 technical scan. Signals are research alerts only; no orders are placed."""
from __future__ import annotations

import json
import logging
import math
import os
import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import requests

DS1 = ("PVT", "PVS", "MSB", "TVS", "PET", "HAH", "BSR", "VPI", "VGC", "DHC", "VTP", "VPB", "MWG")
DNSE_URL = "https://services.entrade.com.vn/chart-api/v2/ohlcs/stock"
DNSE_INDEX_URL = "https://services.entrade.com.vn/chart-api/v2/ohlcs/index"
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
HISTORY_PATH = Path(os.getenv("SIGNAL_HISTORY_PATH", "data/signal_history.jsonl"))
MIN_BARS = 100
LOOKBACK_DAYS = 420
REQUEST_TIMEOUT = 20
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; DS1ResearchAgent/1.0)"}
LOGGER = logging.getLogger("trading_engine.gemini")


class GeminiMalformedResponseError(ValueError):
    """Gemini returned text that did not match the reviewer contract."""


@dataclass
class SetupDiagnostic:
    code: str
    status: str
    checks: list[str] = field(default_factory=list)
    failed_checks: list[str] = field(default_factory=list)
    condition_details: list[dict[str, str]] = field(default_factory=list)
    primary_blocker: str | None = None
    secondary_blockers: list[str] = field(default_factory=list)
    distance_to_trigger: str = "N/A"
    proximity_score: int | None = None
    watch_status: str = "UNKNOWN"


@dataclass
class Signal:
    ticker: str
    regime: str
    strategy: str
    score: int
    entry: float | None
    sl: float | None
    tp1: float | None
    tp2: float | None
    trigger: str
    rr: str
    decision: str
    close: float | None
    as_of: str
    entry_type: str = "—"
    trigger_level: float | None = None
    entry_zone_low: float | None = None
    entry_zone_high: float | None = None
    chase_distance_atr: float | None = None
    rr_tp1: float | None = None
    rr_tp2: float | None = None
    risk_per_share: float | None = None
    decision_reason: str = ""
    setup_diagnostics: list[SetupDiagnostic] = field(default_factory=list)
    best_strategy: str = "UNKNOWN"
    best_proximity_score: int | None = None
    best_blocker: str = "UNKNOWN"
    distance_to_trigger: str = "N/A"
    watch_status: str = "UNKNOWN"


_DISTANCE_SCALES = {"atr": 0.65, "rsi": 3.0, "%": 0.75, "volume": 0.5,
                    "range": 0.25}


def _distance_fraction(distance: str) -> float:
    """Map an existing diagnostic distance to a transparent [0, 1] closeness."""
    if "TRIGGER READY" in distance:
        return 1.0
    match = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(ATR|RSI|%|×|range units)", distance, re.IGNORECASE)
    if not match:
        return 0.0  # categorical FAIL has no measured proximity; do not guess
    value, unit = float(match.group(1)), match.group(2).lower()
    key = "volume" if unit == "×" else "range" if unit == "range units" else unit
    scale = _DISTANCE_SCALES[key]
    return math.exp(-value / scale)


def _proximity_status(score: int | None, trigger_ready: bool = False) -> str:
    if score is None:
        return "UNKNOWN"
    if trigger_ready:
        return "TRIGGER_READY"
    if score >= 90:
        return "VERY_CLOSE"
    if score >= 75:
        return "CLOSE"
    if score >= 50:
        return "WATCH"
    return "FAR"


def _best_proximity(diagnostics: list[SetupDiagnostic]) -> tuple[str, int | None, str, str, str]:
    known = [d for d in diagnostics if d.proximity_score is not None]
    if not known:
        unknown = next((d for d in diagnostics if d.status == "UNKNOWN"), None)
        return (unknown.code if unknown else "UNKNOWN", None,
                unknown.primary_blocker if unknown else "UNKNOWN", "N/A", "UNKNOWN")
    best = max(known, key=lambda d: (d.proximity_score, -int(d.code[1:])))
    return (best.code, best.proximity_score, best.primary_blocker or "None",
            best.distance_to_trigger, best.watch_status)


def _set_signal_proximity(signal: Signal) -> Signal:
    (signal.best_strategy, signal.best_proximity_score, signal.best_blocker,
     signal.distance_to_trigger, signal.watch_status) = _best_proximity(signal.setup_diagnostics)
    return signal


def _diagnose_setup(code: str, conditions: list[tuple[str, bool | None, str]]) -> SetupDiagnostic:
    details = [{"condition": label, "blocker": _blocker_name(label),
                "status": "UNKNOWN" if passed is None else "PASS" if passed else "FAIL",
                "distance": "N/A" if passed is None else "0 / TRIGGER READY" if passed else distance}
               for label, passed, distance in conditions]
    failed = [item["blocker"] for item in details if item["status"] == "FAIL"]
    unknown = any(item["status"] == "UNKNOWN" for item in details)
    status = "UNKNOWN" if unknown else "FAIL" if failed else "PASS"
    unknown_labels = [item["blocker"] for item in details if item["status"] == "UNKNOWN"]
    primary = failed[0] if failed else unknown_labels[0] if unknown_labels else None
    primary_distance = "N/A" if unknown else next(
        (d["distance"] for d in details if d["status"] == "FAIL"), "0 / TRIGGER READY")
    checks = [f"{d['condition']}: {d['status']} | Distance: {d['distance']}" for d in details]
    if unknown:
        proximity_score = None
        watch_status = "UNKNOWN"
    elif not failed:
        proximity_score = 100
        watch_status = "TRIGGER_READY"
    else:
        # Geometric aggregation makes any distant/unmeasured blocker matter; the
        # number of PASS checks cannot hide a blocker that remains far away.
        fractions = [_distance_fraction(d["distance"]) for d in details]
        proximity_score = round(100 * math.prod(fractions) ** (1 / len(fractions))) if fractions else 100
        watch_status = _proximity_status(proximity_score)
    return SetupDiagnostic(code, status, checks, failed, details, primary, failed[1:], primary_distance,
                           proximity_score, watch_status)


def _unknown_setup_diagnostics(reason: str) -> list[SetupDiagnostic]:
    detail = {"condition": reason, "blocker": reason, "status": "UNKNOWN", "distance": "N/A"}
    return [SetupDiagnostic(f"S{i}", "UNKNOWN", [f"{reason}: UNKNOWN | Distance: N/A"], [reason],
                            [detail], reason, [], "N/A") for i in range(1, 6)]


def _blocker_name(label: str) -> str:
    lowered = label.lower()
    if "regime" in lowered:
        return "Regime"
    if "rsi" in lowered:
        return "RSI"
    if "volume" in lowered:
        return "Volume"
    if "hỗ trợ" in lowered:
        return "Support"
    if "breakout" in lowered:
        return "Breakout"
    if "retest" in lowered or "pivot" in lowered:
        return "Pivot/retest price"
    if "xu hướng" in lowered:
        return "Trend structure"
    if "ema" in lowered or "sma" in lowered or "hồi về" in lowered:
        return "Pullback level"
    if "co hẹp" in lowered:
        return "Contraction"
    if "đỉnh 55" in lowered:
        return "Price vs HH55"
    if "nến" in lowered:
        return "Bullish candle"
    if "đỉnh phiên trước" in lowered or "giá đóng phiên trước" in lowered:
        return "Price vs prior bar"
    return label


def _price_distance(shortfall: float, reference: float, atr: float) -> str:
    if shortfall <= 0:
        return "0 / TRIGGER READY"
    pct = shortfall / reference * 100 if reference > 0 else 0.0
    return f"{shortfall / atr:.2f} ATR ({pct:.2f}%)" if atr > 0 else f"{pct:.2f}%"


# Round-trip estimated costs include fees/taxes and are configurable per deployment.
ESTIMATED_ROUND_TRIP_COST_RATE = float(os.getenv("ESTIMATED_ROUND_TRIP_COST_RATE", "0.003"))
MIN_NET_RR_TP1 = float(os.getenv("MIN_NET_RR_TP1", "1.0"))
MIN_NET_RR_TP2 = float(os.getenv("MIN_NET_RR_TP2", "1.8"))
MAX_CHASE_ATR = float(os.getenv("MAX_CHASE_ATR", "0.65"))


def fetch_ohlcv(symbol: str, session: requests.Session | None = None, now: int | None = None,
                endpoint: str | None = None) -> pd.DataFrame:
    """Fetch daily bars. DNSE endpoint is queried per symbol; 429/5xx are retried."""
    client = session or requests.Session()
    end = int(now or time.time())
    params = {"symbol": symbol, "from": end - LOOKBACK_DAYS * 86400, "to": end,
              "resolution": "1D"}
    last_error: Exception | None = None
    for attempt in range(4):
        try:
            response = client.get(endpoint or DNSE_URL, params=params, headers=HEADERS, timeout=REQUEST_TIMEOUT)
            if response.status_code == 429 or response.status_code >= 500:
                if attempt < 3:
                    delay = min(2 ** attempt, 12)
                    retry_after = response.headers.get("Retry-After")
                    time.sleep(min(float(retry_after), 20) if retry_after and retry_after.isdigit() else delay)
                    continue
            response.raise_for_status()
            payload = response.json()
            if not payload.get("t"):
                raise ValueError(f"DNSE returned no bars for {symbol}")
            df = pd.DataFrame({"Date": pd.to_datetime(payload["t"], unit="s", utc=True).tz_convert(None),
                               "Open": payload["o"], "High": payload["h"], "Low": payload["l"],
                               "Close": payload["c"], "Volume": payload["v"]})
            df = df.sort_values("Date").drop_duplicates("Date").reset_index(drop=True)
            if df["Close"].median() < 1000:  # DNSE may express VND prices in thousands.
                df[["Open", "High", "Low", "Close"]] *= 1000
            return df
        except (requests.RequestException, ValueError, KeyError, TypeError) as exc:
            last_error = exc
            if attempt < 3:
                time.sleep(min(2 ** attempt, 12))
    raise RuntimeError(f"DNSE fetch failed for {symbol}: {last_error}")


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    close, high, low = x.Close, x.High, x.Low
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / 14, min_periods=14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / 14, min_periods=14, adjust=False).mean()
    x["RSI14"] = 100 - 100 / (1 + gain / loss.replace(0, float("nan")))
    x["EMA20"] = close.ewm(span=20, min_periods=20, adjust=False).mean()
    x["SMA50"] = close.rolling(50, min_periods=50).mean()
    x["SMA100"] = close.rolling(100, min_periods=100).mean()
    x["ATR14"] = pd.concat([(high-low), (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1).ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    x["Vol20"] = x.Volume.rolling(20, min_periods=20).mean()
    x["HH20"] = high.shift(1).rolling(20, min_periods=20).max()
    x["LL20"] = low.shift(1).rolling(20, min_periods=20).min()
    x["HH55"] = high.shift(1).rolling(55, min_periods=55).max()
    x["LL55"] = low.shift(1).rolling(55, min_periods=55).min()
    x["RANGE20"] = (high.rolling(20).max() - low.rolling(20).min()) / close
    x["RANGE60"] = (high.rolling(60).max() - low.rolling(60).min()) / close
    return x


def classify_regime(market_df: pd.DataFrame | None) -> str:
    # Missing/invalid market data is unknown, never a market condition such as CHOPPY.
    if market_df is None or len(market_df) < 100:
        return "REGIME_UNKNOWN"
    x = add_features(market_df).iloc[-1]
    if any(pd.isna(x[key]) for key in ("RSI14", "EMA20", "SMA50", "SMA100", "ATR14")) or x.Close <= 0 or x.ATR14 <= 0:
        return "REGIME_UNKNOWN"
    trend = x.Close > x.SMA50 > x.SMA100 and x.EMA20 > x.SMA50
    down = x.Close < x.SMA50 < x.SMA100 and x.EMA20 < x.SMA50
    if trend and x.RSI14 >= 48:
        return "TREND"
    if down and x.RSI14 <= 52:
        return "TREND"
    if 35 <= x.RSI14 <= 65 and abs(x.Close / x.SMA50 - 1) < 0.025:
        return "RANGE"
    return "CHOPPY"


def load_market_data(fetcher=fetch_ohlcv) -> tuple[pd.DataFrame | None, str | None, list[str]]:
    """Load VNINDEX, then accept VN30 only when its bars produce a usable regime."""
    errors: list[str] = []
    for symbol in ("VNINDEX", "VN30"):
        try:
            bars = fetcher(symbol, endpoint=DNSE_INDEX_URL)
            regime = classify_regime(bars)
            if regime != "REGIME_UNKNOWN":
                return bars, symbol, errors
            errors.append(f"{symbol}: dữ liệu chỉ số không đủ/hợp lệ để phân loại regime")
        except Exception as exc:
            errors.append(f"{symbol}: {exc}")
    return None, None, errors


def _f(row: pd.Series, key: str, default: float = float("nan")) -> float:
    value = row.get(key, default)
    return float(value) if pd.notna(value) else default


def _net_rr(entry: float, stop: float, target: float, cost_rate: float) -> float:
    """Net reward/risk after estimated round-trip costs (half charged per leg)."""
    side_rate = cost_rate / 2.0
    net_reward = target - entry - side_rate * (entry + target)
    net_risk = entry - stop + side_rate * (entry + stop)
    return net_reward / net_risk if net_risk > 0 else 0.0


def _trade_plan(entry_type: str, close: float, trigger: float, atr: float,
                bar_low: float, bar_high: float, supports: list[float],
                resistances: list[float], cost_rate: float | None = None) -> dict[str, Any]:
    """Build a long-only structure/ATR plan. Exposed for deterministic sanity tests."""
    costs = ESTIMATED_ROUND_TRIP_COST_RATE if cost_rate is None else cost_rate
    zone_pad = 0.20 * atr
    optimal = trigger
    chase_atr = max(0.0, (close - optimal) / atr) if atr > 0 else float("inf")
    result: dict[str, Any] = {"entry_type": entry_type, "trigger_level": trigger,
        "entry_zone_low": max(0.0, optimal - zone_pad), "entry_zone_high": optimal + zone_pad,
        "chase_distance_atr": chase_atr, "entry": None, "sl": None, "tp1": None, "tp2": None,
        "rr_tp1": None, "rr_tp2": None, "risk_per_share": None, "status": "WAIT",
        "decision_reason": ""}
    if chase_atr > MAX_CHASE_ATR:
        result.update(status="CHASE_BLOCKED", decision_reason=f"CHASE_BLOCKED: giá cách entry tối ưu {chase_atr:.2f} ATR (tối đa {MAX_CHASE_ATR:.2f})")
        return result
    entry = optimal
    # Structure stop uses the nearest meaningful swing support with an ATR safety buffer.
    valid_supports = [s for s in supports if 0 < s < entry]
    structure = max(valid_supports) if valid_supports else bar_low
    stop = min(structure - 0.15 * atr, entry - 0.80 * atr)
    if stop <= 0 or stop >= entry:
        result["decision_reason"] = "Không xác định được stop cấu trúc hợp lệ"
        return result
    risk = entry - stop
    # Targets must be actual overhead structure; do not manufacture R multiples as targets.
    overhead = sorted({round(v, 6) for v in resistances if v > entry})
    usable = [v for v in overhead if _net_rr(entry, stop, v, costs) >= MIN_NET_RR_TP1]
    if not usable:
        result.update(entry=entry, sl=stop, risk_per_share=risk,
                      decision_reason="WAIT: kháng cự cấu trúc gần nhất không đạt R:R ròng tối thiểu")
        return result
    tp1 = usable[0]
    later = [v for v in usable[1:] if _net_rr(entry, stop, v, costs) >= MIN_NET_RR_TP2]
    tp2 = later[0] if later else None
    rr1, rr2 = _net_rr(entry, stop, tp1, costs), _net_rr(entry, stop, tp2, costs) if tp2 else None
    result.update(entry=entry, sl=stop, tp1=tp1, tp2=tp2, rr_tp1=rr1, rr_tp2=rr2,
                  risk_per_share=risk)
    if rr1 < MIN_NET_RR_TP1 or tp2 is None:
        result.update(decision_reason="WAIT: không có hai mục tiêu cấu trúc đáp ứng R:R ròng tối thiểu")
        return result
    result.update(status="READY", decision_reason="Trigger xác nhận; Entry/SL/TP theo vùng cấu trúc và ATR")
    return result


def score_signal(ticker: str, bars: pd.DataFrame, regime: str) -> Signal:
    x = add_features(bars)
    as_of = pd.Timestamp(x.iloc[-1].Date).strftime("%Y-%m-%d") if len(x) else "unknown"
    empty = Signal(ticker, regime, "None", 0, None, None, None, None,
                   "Dữ liệu chưa đủ/không hợp lệ", "—", "WAIT / KHÔNG GIAO DỊCH", None, as_of,
                   decision_reason="Dữ liệu chưa đủ/không hợp lệ")
    if regime == "REGIME_UNKNOWN":
        empty.trigger = "Thiếu dữ liệu chỉ số thị trường; chặn tín hiệu fail-safe"
        empty.decision_reason = "REGIME_UNKNOWN: không đủ dữ liệu thị trường; không giao dịch"
        empty.setup_diagnostics = _unknown_setup_diagnostics("REGIME_UNKNOWN: chặn vì thiếu dữ liệu thị trường")
        return empty
    if len(x) < MIN_BARS:
        empty.setup_diagnostics = _unknown_setup_diagnostics(f"Thiếu dữ liệu mã: cần ít nhất {MIN_BARS} nến")
        return empty
    r, prev = x.iloc[-1], x.iloc[-2]
    needed = ["Close", "Open", "High", "Low", "EMA20", "SMA50", "SMA100", "ATR14", "RSI14", "Vol20", "HH20", "LL20", "HH55", "LL55", "RANGE20", "RANGE60"]
    if any(pd.isna(r[k]) for k in needed) or r.Close <= 0 or r.ATR14 <= 0:
        empty.setup_diagnostics = _unknown_setup_diagnostics("Chỉ báo/giá không hợp lệ hoặc còn thiếu")
        return empty
    c, atr, rsi = float(r.Close), float(r.ATR14), float(r.RSI14)
    volume_ratio = float(r.Volume / r.Vol20) if r.Vol20 > 0 else 0.0
    uptrend = c > r.SMA50 > r.SMA100 and r.EMA20 > r.SMA50
    setups: list[tuple[int, int, float, str, str]] = []
    # Support/resistance levels from prior 55 bars; current bar excluded.
    prior = x.iloc[-56:-1]
    supports = [float(prior.Low.rolling(5).min().iloc[i]) for i in range(len(prior)) if i >= 4]
    resistances = [float(prior.High.rolling(5).max().iloc[i]) for i in range(len(prior)) if i >= 4]
    # S1 swing: support touch, then bullish close through prior swing high.
    rsi_s1_distance = f"{max(0.0, rsi - 55, 35 - rsi):.1f} RSI"
    support_s1_gap = float(r.Low) - (float(r.LL20) + .5*atr)
    s1_diag = _diagnose_setup("S1", [
        ("regime RANGE/CHOPPY", regime in ("RANGE", "CHOPPY"), "NOT MET"),
        (f"RSI {rsi:.1f} trong 35–55", 35 <= rsi <= 55, rsi_s1_distance),
        ("chạm vùng hỗ trợ LL20", float(r.Low) <= float(r.LL20) + .5*atr,
         _price_distance(max(0.0, support_s1_gap), c, atr)),
        ("đóng trên đỉnh phiên trước", c > float(prev.High), _price_distance(float(prev.High)-c, c, atr)),
        ("nến đóng tăng", c > float(r.Open), _price_distance(float(r.Open)-c, c, atr)),
    ])
    if s1_diag.status == "PASS":
        setups.append((63 + int(rsi < 45)*5 + int(volume_ratio >= 1)*5, 1, float(prev.High), "S1: hỗ trợ và nến tăng vượt đỉnh phiên trước", "SWING_CONFIRMATION"))
    # S2 requires both an extreme and bullish reversal candle.
    s2_diag = _diagnose_setup("S2", [
        ("regime RANGE", regime == "RANGE", "NOT MET"),
        (f"RSI {rsi:.1f} ≤ 32", rsi <= 32, f"{max(0.0, rsi - 32):.1f} RSI"),
        ("đóng trên giá đóng phiên trước", c > float(prev.Close), _price_distance(float(prev.Close)-c, c, atr)),
        ("nến đóng tăng", c > float(r.Open), _price_distance(float(r.Open)-c, c, atr)),
        ("chạm vùng hỗ trợ LL20", float(r.Low) <= float(r.LL20) + .3*atr,
         _price_distance(float(r.Low)-(float(r.LL20)+.3*atr), c, atr)),
    ])
    if s2_diag.status == "PASS":
        setups.append((65 + int(rsi <= 25)*10 + int(volume_ratio >= .8)*5, 2, float(r.High), "S2: quá bán và nến đảo chiều tăng tại hỗ trợ", "REVERSAL_CONFIRMATION"))
    # Breakout retest: previous bar broke its own 20-bar pivot on volume; current bar retests/holds it.
    prev_pivot = float(x.HH20.iloc[-2])
    prev_volume_known = pd.notna(prev.Volume) and pd.notna(prev.Vol20) and prev.Vol20 > 0
    prev_vr = float(prev.Volume / prev.Vol20) if prev_volume_known else 0.0
    breakout_retest = (float(prev.Close) > prev_pivot and prev_vr >= 1.5 and
                       float(r.Low) <= prev_pivot + .25*atr and c > prev_pivot and c > float(r.Open))
    s3_diag = _diagnose_setup("S3", [
        ("phiên trước breakout pivot 20", float(prev.Close) > prev_pivot,
         _price_distance(prev_pivot-float(prev.Close), float(prev.Close), float(prev.ATR14))),
        (f"volume phiên trước {prev_vr:.2f}× ≥ 1.5×", (prev_vr >= 1.5) if prev_volume_known else None,
         f"{max(0.0, 1.5-prev_vr):.2f}× volume"),
        ("giá retest pivot", float(r.Low) <= prev_pivot + .25*atr,
         _price_distance(float(r.Low)-(prev_pivot+.25*atr), c, atr)),
        ("đóng trên pivot", c > prev_pivot, _price_distance(prev_pivot-c, c, atr)),
        ("nến retest đóng tăng", c > float(r.Open), _price_distance(float(r.Open)-c, c, atr)),
    ])
    if s3_diag.status == "PASS":
        setups.append((70 + int(prev_vr >= 2)*10 + int(uptrend)*5, 3, prev_pivot, "S3: breakout có volume, retest pivot và đóng giữ phía trên", "BREAKOUT_RETEST"))
    near_ema20 = float(r.Low) <= float(r.EMA20) + .35*atr and c >= float(r.EMA20)
    near_ema50 = float(r.Low) <= float(r.SMA50) + .35*atr and c >= float(r.SMA50)
    s4_diag = _diagnose_setup("S4", [
        ("regime TREND", regime == "TREND", "NOT MET"),
        ("cấu trúc xu hướng tăng", uptrend, "NOT MET"),
        ("hồi về EMA20 hoặc SMA50", near_ema20 or near_ema50,
         _price_distance(min(max(float(r.Low)-(.35*atr+float(r.EMA20)), float(r.EMA20)-c, 0),
                              max(float(r.Low)-(.35*atr+float(r.SMA50)), float(r.SMA50)-c, 0)), c, atr)),
        ("nến đóng tăng", c > float(r.Open), _price_distance(float(r.Open)-c, c, atr)),
        ("đóng trên đỉnh phiên trước", c > float(prev.High), _price_distance(float(prev.High)-c, c, atr)),
    ])
    if s4_diag.status == "PASS":
        level = float(r.EMA20 if near_ema20 else r.SMA50)
        setups.append((68 + int(volume_ratio >= .8)*7 + int(rsi < 68)*5, 4, level, "S4: hồi EMA20/EMA50 và nến tăng xác nhận", "PULLBACK_CONFIRMATION"))
    near_high = c >= float(r.HH55) - 1.5*atr
    s5_diag = _diagnose_setup("S5", [
        ("nền co hẹp RANGE20 < 0.65× RANGE60", float(r.RANGE20) < float(r.RANGE60)*.65,
         f"{max(0.0, float(r.RANGE20)-float(r.RANGE60)*.65):.2f} range units"),
        ("giá gần đỉnh 55 phiên", near_high,
         _price_distance(float(r.HH55)-1.5*atr-c, c, atr)),
        ("breakout/retest đạt điều kiện S3",
         True if s3_diag.status == "PASS" else None if s3_diag.status == "UNKNOWN" else False,
         "NOT MET"),
    ])
    diagnostics = [s1_diag, s2_diag, s3_diag, s4_diag, s5_diag]
    if s5_diag.status == "PASS":
        setups.append((70 + int(prev_vr >= 1.8)*10 + int(uptrend)*5, 5, prev_pivot, "S5: nền co hẹp, breakout có volume và retest pivot", "VCP_BREAKOUT_RETEST"))
    if not setups:
        return _set_signal_proximity(Signal(ticker, regime, "None", 0, None, None, None, None,
                      "Chưa có trigger S1–S5 xác nhận; chờ retest/đảo chiều", "—", "WAIT / KHÔNG GIAO DỊCH", c, as_of,
                      decision_reason="Chưa có trigger xác nhận", setup_diagnostics=diagnostics))
    score, idx, trigger_level, trigger, entry_type = max(setups, key=lambda s: s[0])
    plan = _trade_plan(entry_type, c, trigger_level, atr, float(r.Low), float(r.High), supports, resistances)
    name = {1: "S1 Swing", 2: "S2 Mean Reversion", 3: "S3 Breakout Momentum", 4: "S4 Pullback Trend Following", 5: "S5 VCP"}[idx]
    decision = "BUY WATCH / CHỜ XÁC NHẬN" if score >= 70 and plan["status"] == "READY" else "WAIT / KHÔNG GIAO DỊCH"
    if plan["status"] == "CHASE_BLOCKED":
        decision = "CHASE_BLOCKED"
    reason = plan["decision_reason"]
    rr = f"net {plan['rr_tp1']:.2f}R / {plan['rr_tp2']:.2f}R" if plan.get("rr_tp2") is not None else "—"
    return _set_signal_proximity(Signal(ticker, regime, name, min(score, 100), plan["entry"], plan["sl"], plan["tp1"], plan["tp2"],
                  trigger, rr, decision, c, as_of, entry_type, trigger_level, plan["entry_zone_low"],
                  plan["entry_zone_high"], plan["chase_distance_atr"], plan["rr_tp1"], plan["rr_tp2"],
                  plan["risk_per_share"], reason, diagnostics))


def record_signals(signals: list[Signal], path: Path = HISTORY_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).isoformat()
    with path.open("a", encoding="utf-8") as out:
        for signal in signals:
            row = asdict(signal) | {"recorded_at": stamp}
            out.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def _gemini_error_details(exc: Exception, api_key: str) -> tuple[str, str, str]:
    """Return safe category/status/message diagnostics without exposing credentials."""
    response = getattr(exc, "response", None)
    status = (getattr(exc, "code", None) or getattr(exc, "status_code", None)
              or getattr(response, "status_code", None))
    raw_message = getattr(exc, "message", None) or str(exc) or type(exc).__name__
    message_lower = str(raw_message).lower()
    status_label = str(status).upper() if status is not None else ""
    try:
        status_text = str(int(status)) if status is not None else "UNKNOWN"
    except (TypeError, ValueError):
        status_text = str(status)[:40]
    try:
        status_num = int(status)
    except (TypeError, ValueError):
        status_num = None
    if isinstance(exc, GeminiMalformedResponseError):
        category = "MALFORMED_RESPONSE"
    elif status_num in (401, 403) or any(marker in message_lower for marker in
            ("api_key_invalid", "api key not valid", "invalid api key", "api key is invalid")):
        category = "API_KEY_OR_PERMISSION"
    elif status_num == 429 or "RESOURCE_EXHAUSTED" in status_label or any(
            marker in message_lower for marker in ("quota", "rate limit", "resource_exhausted")):
        category = "QUOTA_OR_RATE_LIMIT"
    elif status_num == 404 or "NOT_FOUND" in status_label:
        category = "MODEL_NOT_FOUND"
    elif status_num is not None and 400 <= status_num < 500:
        category = "INVALID_REQUEST"
    elif status_num is not None and status_num >= 500:
        category = "API_SERVER_ERROR"
    else:
        category = "CLIENT_OR_NETWORK_ERROR"
    message = str(raw_message).replace(api_key, "[REDACTED]")
    message = re.sub(r"(?i)(AIza[0-9A-Za-z_-]{20,})", "[REDACTED]", message)
    message = re.sub(r"[\r\n\t]+", " ", message).strip()[:1000]
    return category, status_text, message


def _validate_gemini_review(text: str, signals: list[Signal]) -> dict[str, dict[str, Any]]:
    """Validate one reviewer object per ticker; ignore any untrusted trading fields."""
    fields = ("setup_summary", "strengths", "weaknesses", "primary_risk_blocker",
              "fomo_chase_check", "conditions_before_trigger", "verdict")
    try:
        payload = json.loads(text)
    except (json.JSONDecodeError, TypeError) as exc:
        raise GeminiMalformedResponseError("Gemini response was not valid JSON") from exc
    reviews = payload.get("reviews") if isinstance(payload, dict) else None
    expected = {signal.ticker for signal in signals}
    if not isinstance(reviews, list):
        raise GeminiMalformedResponseError("review JSON must contain a reviews array")
    by_ticker = {}
    for review in reviews:
        if not isinstance(review, dict) or review.get("ticker") not in expected:
            raise GeminiMalformedResponseError("review contains missing or unexpected ticker")
        ticker = review["ticker"]
        if ticker in by_ticker or any(key not in review for key in fields):
            raise GeminiMalformedResponseError(f"review for {ticker} is duplicated or missing fields")
        for key in ("setup_summary", "primary_risk_blocker", "fomo_chase_check"):
            if not isinstance(review[key], str) or not review[key].strip():
                raise GeminiMalformedResponseError(f"{ticker}.{key} must be a non-empty string")
        for key in ("strengths", "weaknesses", "conditions_before_trigger"):
            if not isinstance(review[key], list) or not all(isinstance(item, str) for item in review[key]):
                raise GeminiMalformedResponseError(f"{ticker}.{key} must be a list of strings")
        if review["verdict"] not in {"PASS", "CAUTION", "REJECT"}:
            raise GeminiMalformedResponseError(f"{ticker}.verdict must be PASS, CAUTION, or REJECT")
        by_ticker[ticker] = review
    if set(by_ticker) != expected:
        raise GeminiMalformedResponseError("review response omitted one or more tickers")
    return by_ticker


def _format_gemini_review(reviews: dict[str, dict[str, Any]], signals: list[Signal]) -> str:
    lines = []
    for signal in signals:
        review = reviews[signal.ticker]
        lines.extend([f"{signal.ticker} — Python Decision: {signal.decision}",
                      f"Setup summary: {review['setup_summary']}",
                      "Strengths: " + ("; ".join(review["strengths"]) or "UNKNOWN"),
                      "Weaknesses: " + ("; ".join(review["weaknesses"]) or "UNKNOWN"),
                      f"Primary risk/blocker: {review['primary_risk_blocker']}",
                      f"FOMO/chase check: {review['fomo_chase_check']}",
                      "Conditions before trigger: " + ("; ".join(review["conditions_before_trigger"]) or "UNKNOWN"),
                      f"Reviewer verdict: {review['verdict']}"])
        if signal.decision == "WAIT":
            lines.append("Decision remains WAIT; reviewer cannot upgrade Python Decision.")
    return "\n".join(lines)

def gemini_review(signals: list[Signal]) -> str:
    """Ask Gemini to challenge Python-computed context; it has no decision authority."""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        LOGGER.warning("Gemini review unavailable exception_type=None category=MISSING_API_KEY status=UNKNOWN message=GEMINI_API_KEY is not configured")
        return "Gemini review unavailable: MISSING_API_KEY; Python signal/report remains authoritative."
    snapshot = [{"ticker": s.ticker, "regime": s.regime, "strategy": s.strategy,
                 "score": s.score, "entry": s.entry, "entry_type": s.entry_type,
                 "trigger_level": s.trigger_level, "entry_zone_low": s.entry_zone_low,
                 "entry_zone_high": s.entry_zone_high, "chase_distance_atr": s.chase_distance_atr,
                 "sl": s.sl, "tp1": s.tp1, "tp2": s.tp2, "rr_tp1": s.rr_tp1,
                 "rr_tp2": s.rr_tp2, "risk_per_share": s.risk_per_share,
                 "decision_reason": s.decision_reason, "trigger": s.trigger, "rr": s.rr,
                 "decision": s.decision, "close": s.close, "as_of": s.as_of,
                 "setup_diagnostics": [asdict(d) for d in s.setup_diagnostics]} for s in signals]
    prompt = ("You are a reviewer only. Use only this Python-computed JSON as facts. Do not recalculate or modify "
              "market regime, strategy scores, Entry, SL, TP1/TP2, R:R, anti-chase, or Python Decision. Do not invent "
              "values. For every WAIT preserve WAIT; list missing trigger/confirmation as conditions and use UNKNOWN "
              "when data is missing. Return only JSON in this shape: {\"reviews\":[{\"ticker\":... , \"setup_summary\":string, \"strengths\":string[], \"weaknesses\":string[], \"primary_risk_blocker\":string, \"fomo_chase_check\":string, \"conditions_before_trigger\":string[], \"verdict\":\"PASS|CAUTION|REJECT\"}]}. Include each ticker exactly once. The verdict is a review assessment, never a buy/sell signal.\n" + json.dumps(snapshot, ensure_ascii=False))
    try:
        from google import genai
        # A client belongs to this review only. Never cache it: callers may
        # close SDK clients elsewhere, and a closed client cannot send requests.
        client = genai.Client(api_key=api_key)
        try:
            response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        finally:
            # google-genai Client exposes close(); keep compatibility with SDK
            # variants that omit it, and do not turn a successful review into
            # a failure solely because cleanup raised.
            close = getattr(client, "close", None)
            if callable(close):
                try:
                    close()
                except Exception as close_exc:
                    LOGGER.warning("Gemini client cleanup failed exception_type=%s",
                                   type(close_exc).__name__)
        if not response or not getattr(response, "text", None):
            raise GeminiMalformedResponseError("Gemini returned an empty response")
        review = _validate_gemini_review(response.text, signals)
        return _format_gemini_review(review, signals)
    except Exception as exc:
        category, status, message = _gemini_error_details(exc, api_key)
        LOGGER.error("Gemini review failed exception_type=%s category=%s status=%s message=%s",
                     type(exc).__name__, category, status, message)
        return (f"Gemini review unavailable: {category} (HTTP/API status {status}; "
                f"{type(exc).__name__}: {message}); Python signal/report remains authoritative.")

def _fmt(value: float | None) -> str:
    return f"{value:,.0f}" if value is not None else "—"


def _fmt_ratio(value: float | None) -> str:
    return f"{value:.2f}R" if value is not None else "—"


def _format_setup_diagnostics(diagnostics: list[SetupDiagnostic]) -> str:
    names = {"S1": "Swing", "S2": "Mean Reversion", "S3": "Breakout Momentum",
             "S4": "Pullback Trend Following", "S5": "VCP"}
    symbols = {"PASS": "✅", "FAIL": "❌", "UNKNOWN": "❔"}
    lines = []
    for diagnostic in diagnostics:
        if diagnostic.status == "PASS":
            summary = (f"{diagnostic.code} PASS | {names.get(diagnostic.code, '')} | "
                       f"Proximity: 100/100 (TRIGGER_READY) | Distance: 0")
        elif diagnostic.status == "UNKNOWN":
            summary = f"{diagnostic.code} UNKNOWN | {names.get(diagnostic.code, '')} | Blocker: {diagnostic.primary_blocker or 'thiếu dữ liệu'} | Distance: N/A"
        else:
            summary = (f"{diagnostic.code} FAIL | {names.get(diagnostic.code, '')} | "
                       f"Proximity: {diagnostic.proximity_score}/100 ({diagnostic.watch_status}) | "
                       f"Primary blocker: {diagnostic.primary_blocker} | Distance: {diagnostic.distance_to_trigger}")
            if diagnostic.secondary_blockers:
                summary += " | Secondary: " + ", ".join(diagnostic.secondary_blockers)
        lines.append(summary)
        lines.extend(f"  {symbols.get(d.get('status', 'UNKNOWN'), '❔')} {d.get('condition')}: {d.get('status')} | Distance: {d.get('distance', 'N/A')}"
                     for d in diagnostic.condition_details)
    if not lines:
        return "Chưa có chẩn đoán setup"
    ranked = sorted(diagnostics, key=lambda d: (d.proximity_score is None,
                                                 -(d.proximity_score or 0), int(d.code[1:])))
    lines.append("Strategy proximity ranking (chỉ diagnostic; không đổi Decision): " + " > ".join(
        f"{d.code}({d.proximity_score if d.proximity_score is not None else 'UNKNOWN'}/100, {d.watch_status})"
        for d in ranked))
    return "\n".join(lines)


def _format_watchlist(signals: list[Signal]) -> str:
    ranked = sorted(signals, key=lambda s: (s.best_proximity_score is None,
                                             -(s.best_proximity_score or 0), s.ticker))
    lines = ["DS1 WATCHLIST RANKING (diagnostic only; BUY/WAIT unchanged)",
             "#  Ticker  Score  Best strategy  Status         Primary blocker / distance"]
    for rank, signal in enumerate(ranked, 1):
        score = f"{signal.best_proximity_score:>3}/100" if signal.best_proximity_score is not None else " UNKNOWN"
        lines.append(f"{rank:>2} {signal.ticker:<6} {score:<8} {signal.best_strategy:<14} "
                     f"{signal.watch_status:<14} {signal.best_blocker} / {signal.distance_to_trigger} | "
                     f"Decision: {signal.decision}")
    return "\n".join(lines)


def format_report(signals: list[Signal], review: str) -> str:
    lines = ["📊 TRADING ENGINE S1–S5 | DS1 | DIAGNOSTIC V2", "Python scoring • Gemini phản biện • Cảnh báo tham khảo, không đặt lệnh", ""]
    for s in signals:
        lines.extend([f"{s.ticker} | Regime: {s.regime} | Strategy: {s.strategy} | Score: {s.score}/100",
                      f"Entry: {_fmt(s.entry)} ({s.entry_type}) | Zone: {_fmt(s.entry_zone_low)}–{_fmt(s.entry_zone_high)} | SL: {_fmt(s.sl)} | TP1: {_fmt(s.tp1)} | TP2: {_fmt(s.tp2)}",
                      f"Trigger: {s.trigger} @ {_fmt(s.trigger_level)} | Chase: {s.chase_distance_atr:.2f} ATR" if s.chase_distance_atr is not None else f"Trigger: {s.trigger} @ {_fmt(s.trigger_level)}",
                      f"R:R ròng: TP1 {_fmt_ratio(s.rr_tp1)} / TP2 {_fmt_ratio(s.rr_tp2)} | Rủi ro/cp: {_fmt(s.risk_per_share)}",
                      f"Decision: {s.decision} — {s.decision_reason} | Giá: {_fmt(s.close)} | {s.as_of}",
                      f"S1–S5 diagnostics: {_format_setup_diagnostics(s.setup_diagnostics)}", ""])
    lines.extend([_format_watchlist(signals), "", "Gemini review:", review])
    return "\n".join(lines)


def main() -> int:
    session = requests.Session()
    datasets: dict[str, pd.DataFrame] = {}
    errors: list[str] = []
    market_bars, market_source, market_errors = load_market_data(
        lambda symbol, endpoint=None: fetch_ohlcv(symbol, session=session, endpoint=endpoint))
    errors.extend(market_errors)
    if market_bars is not None and market_source is not None:
        datasets[market_source] = market_bars
    for i, ticker in enumerate(DS1):
        try:
            datasets[ticker] = fetch_ohlcv(ticker, session=session)
        except Exception as exc:
            errors.append(f"{ticker}: {exc}")
        if i < len(DS1) - 1:
            time.sleep(0.4)  # be gentle with the public chart endpoint
    regime = classify_regime(market_bars)
    signals = [score_signal(t, datasets[t], regime) if t in datasets else
               Signal(t, regime, "None", 0, None, None, None, None, "Không lấy được dữ liệu", "—", "WAIT / KHÔNG GIAO DỊCH", None, "unknown") for t in DS1]
    record_signals(signals)
    review = gemini_review(signals)
    report = format_report(signals, review)
    if errors:
        report += "\n\nData errors:\n" + "\n".join(errors[:8])
    print(report)
    token, chat_id = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if token and chat_id:
        # Telegram sendMessage allows up to 4096 chars; this compact report is split defensively.
        chunks = [report[i:i+3900] for i in range(0, len(report), 3900)]
        for chunk in chunks:
            response = session.post(f"https://api.telegram.org/bot{token}/sendMessage",
                                    json={"chat_id": chat_id, "text": chunk}, timeout=20)
            response.raise_for_status()
    else:
        print("Telegram chưa cấu hình; chỉ in báo cáo.")
    return 0 if len(datasets) > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
